# Home Equity Analysis — Streamlit + Plotly

A self-contained recreation of the **Task 2: Design a BI dashboard** report from the supplied SAS Viya use-case guide, using the supplied HOMEEQUITY CSV. The guide documents one SAS Visual Analytics report page named **Interactive charts**, four linked automatic charts, and global automatic actions. This project keeps that one-page scope rather than inventing additional SAS report pages.

## Run it

Python 3.10+ is recommended.

```bash
cd bi_dashboard
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

Or, on macOS/Linux, run `./run.sh` to install dependencies and start Streamlit. The application binds to `0.0.0.0` for hosted/container environments. Open the local URL printed by Streamlit.

## Report contents

- KPI cards: application count, default/delinquency rate, average requested loan, average debt-to-income.
- **Loan status**: donut with outside percent labels (BAD=0 current; BAD=1 default/seriously delinquent).
- **Requested loan amount distribution**: loan amount histogram split by loan status.
- **Requested loan totals over time**: monthly sum of requested loan amounts split by status.
- **Applicant profile by loan status**: average oldest credit-line age and average debt-to-income, with separate axes.
- Sidebar report filters: Region, State, loan purpose, occupation, loan status; page filters: requested loan range and application date.
- Expandable data notes and source field profile, including field type and missingness.

## SAS Viya → Python mapping

| SAS Visual Analytics item | This project |
|---|---|
| Measures and categories | Numeric and categorical source columns, documented in `src/data_engine.py`; business labels are shown in the field profile. |
| BAD target | Derived `LOAN_STATUS` label: Current / Default or delinquent. |
| APPDATE format (MONYY7) | Converted from SAS day count since 1960-01-01 into a Pandas datetime and monthly time bucket. |
| Average aggregation on Age of Oldest Credit Line | Null-aware mean of `CLAGE`, by loan status in the profile visual. |
| Key Value objects | Styled `st.metric` KPI cards. |
| Page/report prompts | Streamlit sidebar multiselects, range slider, and date control. |
| Automatic actions / linked objects | Shared filter state re-renders all chart objects and KPIs consistently. |
| Containers / report layout | One-page, two-column responsive chart grid built from Streamlit columns and a bordered container. |
| SAS Visual Analytics colors | Coordinated indigo, teal, muted blue, gold, and red Plotly palette plus Streamlit theme in `.streamlit/config.toml`. |

The source guide does **not** specify a custom calculated profit, margin, or year-over-year metric. This dataset has no cost/profit fields, so those measures are not fabricated. The data layer includes a derived loan-to-value percentage (`LOAN / VALUE × 100`) for extension and the measures actually used are calculated null-safely.

## Project structure

```text
bi_dashboard/
├── .streamlit/config.toml
├── data/dataset.csv
├── src/__init__.py
├── src/data_engine.py
├── src/visuals.py
├── src/components.py
├── app.py
├── requirements.txt
├── README.md
└── run.sh
```

## Data handling and limitations

- The supplied CSV is copied to `data/dataset.csv`; no network data access is used.
- `APPDATE` is treated as a SAS date numeric value, consistent with the guide's MONYY7 formatting instruction.
- Missing fields are preserved. Pandas calculations and Plotly charts use available non-null values; there is no imputation.
- The supplied source has 5,960 records and includes a large missing share for DEBTINC. Its mean is therefore explicitly computed from observed values only.
- SAS object click-selection semantics are represented by shared explicit filter controls (not custom click callbacks). Changes update all four visuals and KPIs without refreshing the browser page.
