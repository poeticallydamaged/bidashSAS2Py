"""Home Equity dashboard application package."""
