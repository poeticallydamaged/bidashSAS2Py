"""Data loading, metadata, and reusable calculations for the dashboard."""
from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import streamlit as st

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "dataset.csv"
SAS_EPOCH = pd.Timestamp("1960-01-01")

# Original HOMEEQUITY dictionary: BAD is the binary target. Geography and
# APPDATE were appended in this practice dataset and are not model inputs.
LABELS = {
    "BAD": "Loan status",
    "LOAN": "Requested loan amount",
    "MORTDUE": "Existing mortgage due",
    "VALUE": "Current property value",
    "REASON": "Loan purpose",
    "JOB": "Occupation",
    "YOJ": "Years at present job",
    "DEROG": "Derogatory reports",
    "DELINQ": "Delinquent credit lines",
    "CLAGE": "Age of oldest credit line (months)",
    "NINQ": "Recent credit inquiries",
    "CLNO": "Number of credit lines",
    "DEBTINC": "Debt-to-income ratio (%)",
    "APPDATE": "Application date",
    "CITY": "City",
    "STATE": "State",
    "DIVISION": "Census division",
    "REGION": "Region",
}

PALETTE = {
    "purple": "#5B4B8A",
    "violet": "#8B7BB8",
    "blue": "#2E6F95",
    "teal": "#4E9A9A",
    "gold": "#D9A441",
    "red": "#C65D5D",
    "ink": "#202B3C",
    "muted": "#68758A",
    "grid": "#E8ECF2",
}


@st.cache_data(show_spinner="Loading and preparing HOMEEQUITY…")
def load_data(path: str = str(DATA_PATH)) -> pd.DataFrame:
    """Load source CSV and add readable labels and SAS-date interpretation."""
    df = pd.read_csv(path, low_memory=False)
    # APPDATE is encoded as the number of days since the SAS epoch (1960-01-01).
    df["APPLICATION_DATE"] = SAS_EPOCH + pd.to_timedelta(df["APPDATE"], unit="D")
    df["APPLICATION_MONTH"] = df["APPLICATION_DATE"].dt.to_period("M").dt.to_timestamp()
    df["LOAN_STATUS"] = df["BAD"].map({0: "Current", 1: "Default / delinquent"})
    df["LOAN_PURPOSE"] = df["REASON"].fillna("Missing")
    df["OCCUPATION"] = df["JOB"].fillna("Missing")
    df["REGION_LABEL"] = df["REGION"].fillna("Missing")
    df["LTV_PCT"] = np.where(df["VALUE"].gt(0), df["LOAN"] / df["VALUE"] * 100, np.nan)
    return df


@st.cache_data(show_spinner=False)
def apply_filters(
    df: pd.DataFrame,
    regions: Iterable[str] | None = None,
    states: Iterable[str] | None = None,
    purposes: Iterable[str] | None = None,
    occupations: Iterable[str] | None = None,
    statuses: Iterable[str] | None = None,
    loan_range: tuple[float, float] | None = None,
    date_range: tuple[pd.Timestamp, pd.Timestamp] | None = None,
) -> pd.DataFrame:
    """Apply dashboard report-level and page-level filters."""
    out = df
    for column, selected in (
        ("REGION", regions), ("STATE", states), ("LOAN_PURPOSE", purposes),
        ("OCCUPATION", occupations), ("LOAN_STATUS", statuses),
    ):
        if selected:
            out = out[out[column].isin(selected)]
    if loan_range is not None:
        out = out[out["LOAN"].between(loan_range[0], loan_range[1], inclusive="both")]
    if date_range is not None:
        start, end = date_range
        out = out[out["APPLICATION_DATE"].between(start, end, inclusive="both")]
    return out.copy()


def kpi_summary(df: pd.DataFrame) -> dict[str, float | int]:
    """Calculate summary statistics, preserving null-aware denominators."""
    n = len(df)
    return {
        "applications": n,
        "default_rate": float(df["BAD"].mean()) if n else 0.0,
        "avg_loan": float(df["LOAN"].mean()) if n else 0.0,
        "median_loan": float(df["LOAN"].median()) if n else 0.0,
        "avg_debtinc": float(df["DEBTINC"].mean()) if df["DEBTINC"].notna().any() else np.nan,
        "missing_debtinc_pct": float(df["DEBTINC"].isna().mean() * 100) if n else 0.0,
    }


def monthly_loan_totals(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate requested loan amount by application month and status."""
    if df.empty:
        return pd.DataFrame(columns=["APPLICATION_MONTH", "LOAN_STATUS", "LOAN_SUM", "APPLICATIONS"])
    return (df.groupby(["APPLICATION_MONTH", "LOAN_STATUS"], observed=True)
            .agg(LOAN_SUM=("LOAN", "sum"), APPLICATIONS=("LOAN", "size"))
            .reset_index().sort_values("APPLICATION_MONTH"))


def field_profile(df: pd.DataFrame) -> pd.DataFrame:
    """Return source-column types, missingness, and observed cardinalities."""
    records = []
    for col in [c for c in LABELS if c in df.columns]:
        records.append({
            "Field": col,
            "Label": LABELS[col],
            "Type": "Category" if df[col].dtype == "object" else "Measure",
            "Missing": int(df[col].isna().sum()),
            "Missing %": float(df[col].isna().mean() * 100),
            "Distinct": int(df[col].nunique(dropna=True)),
        })
    return pd.DataFrame(records)
