"""Reusable Streamlit interface components and filtering controls."""
from __future__ import annotations

import pandas as pd
import streamlit as st


def inject_styles() -> None:
    st.markdown("""<style>
    .block-container {padding-top: 1.25rem; padding-bottom: 2rem; max-width: 1500px;}
    [data-testid="stMetric"] {background:#fff; border:1px solid #e8ecf2; border-radius:12px;
      padding:15px 17px; box-shadow:0 2px 8px rgba(32,43,60,.04);}
    [data-testid="stMetricLabel"] {color:#68758a; font-size:.88rem;}
    [data-testid="stMetricValue"] {color:#202b3c; font-weight:700;}
    .dashboard-caption {color:#68758a; font-size:.92rem; margin-top:-.6rem;}
    .section-title {font-size:1.05rem; font-weight:650; color:#202b3c; margin:.15rem 0 .2rem 0;}
    </style>""", unsafe_allow_html=True)


def _options(df: pd.DataFrame, col: str) -> list[str]:
    return sorted(df[col].dropna().astype(str).unique().tolist())


def sidebar_filters(df: pd.DataFrame) -> dict:
    with st.sidebar:
        st.markdown("## Report filters")
        st.caption("Global filters apply to every visualization.")
        regions = st.multiselect("Region", _options(df, "REGION"), key="f_regions")
        states = st.multiselect("State", _options(df, "STATE"), key="f_states")
        purposes = st.multiselect("Loan purpose", _options(df, "LOAN_PURPOSE"), key="f_purposes")
        jobs = st.multiselect("Occupation", _options(df, "OCCUPATION"), key="f_jobs")
        statuses = st.multiselect("Loan status", _options(df, "LOAN_STATUS"), key="f_status")
        st.divider()
        st.markdown("### Page filters")
        min_loan, max_loan = int(df["LOAN"].min()), int(df["LOAN"].max())
        loan_range = st.slider("Requested loan amount", min_loan, max_loan,
                               (min_loan, max_loan), step=1000, format="$%d")
        min_date, max_date = df["APPLICATION_DATE"].min().date(), df["APPLICATION_DATE"].max().date()
        date_range = st.date_input("Application date", value=(min_date, max_date), min_value=min_date, max_value=max_date)
        if isinstance(date_range, tuple) and len(date_range) == 2:
            date_range = (pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1]))
        else:
            date_range = None
        st.divider()
        st.caption("Source: HOMEEQUITY practice data. BAD = 1 indicates default or serious delinquency.")
    return {"regions": regions, "states": states, "purposes": purposes,
            "occupations": jobs, "statuses": statuses, "loan_range": loan_range,
            "date_range": date_range}
