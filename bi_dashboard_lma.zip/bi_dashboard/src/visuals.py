"""Plotly visual objects used by the SAS-inspired Interactive charts page."""
from __future__ import annotations

import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd

from .data_engine import PALETTE

STATUS_COLORS = {"Current": PALETTE["teal"], "Default / delinquent": PALETTE["red"]}


def base_layout(fig: go.Figure, height: int = 340) -> go.Figure:
    fig.update_layout(
        height=height, margin=dict(l=18, r=18, t=20, b=18),
        paper_bgcolor="white", plot_bgcolor="white",
        font=dict(family="Inter, Arial, sans-serif", color=PALETTE["ink"], size=12),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hoverlabel=dict(bgcolor="white", bordercolor=PALETTE["grid"], font_color=PALETTE["ink"]),
    )
    fig.update_xaxes(showgrid=False, linecolor=PALETTE["grid"], zeroline=False)
    fig.update_yaxes(showgrid=True, gridcolor=PALETTE["grid"], zeroline=False)
    return fig


def status_donut(df: pd.DataFrame) -> go.Figure:
    counts = df["LOAN_STATUS"].value_counts().reindex(["Current", "Default / delinquent"]).dropna()
    fig = go.Figure(go.Pie(
        labels=counts.index, values=counts.values, hole=0.62,
        marker=dict(colors=[STATUS_COLORS[x] for x in counts.index], line=dict(color="white", width=3)),
        textinfo="percent+label", textposition="outside", textfont=dict(size=13, color="#40365F"),
        hovertemplate="%{label}<br>Applications: %{value:,}<br>Share: %{percent}<extra></extra>",
        sort=False,
    ))
    fig.update_layout(showlegend=False, annotations=[dict(
        text=f"{len(df):,}<br><span style='font-size:11px'>applications</span>",
        x=0.5, y=0.5, showarrow=False, font=dict(size=21, color=PALETTE["ink"]),
    )])
    return base_layout(fig)


def loan_histogram(df: pd.DataFrame) -> go.Figure:
    fig = px.histogram(
        df, x="LOAN", color="LOAN_STATUS", nbins=32, barmode="overlay", opacity=0.8,
        color_discrete_map=STATUS_COLORS,
        category_orders={"LOAN_STATUS": ["Current", "Default / delinquent"]},
        hover_data={"LOAN_STATUS": True, "LOAN": ":$,.0f"},
    )
    fig.update_traces(hovertemplate="%{fullData.name}<br>Requested loan: $%{x:,.0f}<br>Applications: %{y}<extra></extra>")
    fig.update_xaxes(title="Requested loan amount", tickprefix="$", tickformat="~s")
    fig.update_yaxes(title="Applications", rangemode="tozero")
    return base_layout(fig)


def monthly_trend(df: pd.DataFrame) -> go.Figure:
    monthly = df.groupby(["APPLICATION_MONTH", "LOAN_STATUS"], observed=True).agg(
        LOAN_SUM=("LOAN", "sum"), APPLICATIONS=("LOAN", "size")
    ).reset_index().sort_values("APPLICATION_MONTH")
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    for status in ["Current", "Default / delinquent"]:
        sub = monthly[monthly["LOAN_STATUS"] == status]
        if sub.empty:
            continue
        fig.add_trace(go.Scatter(
            x=sub["APPLICATION_MONTH"], y=sub["LOAN_SUM"], name=f"{status} · total requested",
            mode="lines+markers", line=dict(color=STATUS_COLORS[status], width=2.5),
            marker=dict(size=6), customdata=sub["APPLICATIONS"],
            hovertemplate="%{x|%b %Y}<br>Total loan requests: $%{y:,.0f}<br>Applications: %{customdata:,}<extra></extra>",
        ), secondary_y=False)
    fig.update_xaxes(title="Application month", tickformat="%b\n%Y")
    fig.update_yaxes(title="Total requested amount", tickprefix="$", tickformat="~s", secondary_y=False)
    fig.update_layout(legend=dict(orientation="h", yanchor="bottom", y=1.02, x=0, xanchor="left"))
    return base_layout(fig, height=350)


def profile_by_status(df: pd.DataFrame) -> go.Figure:
    summary = df.groupby("LOAN_STATUS", observed=True).agg(
        average_credit_age=("CLAGE", "mean"), average_debtinc=("DEBTINC", "mean"),
    ).reindex(["Current", "Default / delinquent"]).dropna(how="all").reset_index()
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Bar(
        x=summary["LOAN_STATUS"], y=summary["average_credit_age"], name="Avg. oldest credit line",
        marker_color=PALETTE["blue"],
        hovertemplate="%{x}<br>Average age: %{y:.1f} months<extra></extra>",
    ), secondary_y=False)
    fig.add_trace(go.Scatter(
        x=summary["LOAN_STATUS"], y=summary["average_debtinc"], name="Avg. debt-to-income",
        mode="lines+markers+text", text=summary["average_debtinc"].map(lambda x: f"{x:.1f}%" if pd.notna(x) else ""),
        textposition="top center", marker=dict(color=PALETTE["gold"], size=10),
        line=dict(color=PALETTE["gold"], width=2),
        hovertemplate="%{x}<br>Average debt-to-income: %{y:.1f}%<extra></extra>",
    ), secondary_y=True)
    fig.update_xaxes(title="Loan status")
    fig.update_yaxes(title="Credit age (months)", secondary_y=False)
    fig.update_yaxes(title="Debt-to-income (%)", secondary_y=True, showgrid=False)
    return base_layout(fig)
