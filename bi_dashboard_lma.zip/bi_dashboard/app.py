"""SAS Viya HOMEEQUITY report recreated with Streamlit and Plotly."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from src.components import inject_styles, sidebar_filters
from src.data_engine import apply_filters, field_profile, kpi_summary, load_data
from src.visuals import loan_histogram, monthly_trend, profile_by_status, status_donut

st.set_page_config(page_title="Home Equity Analysis", page_icon="🏠", layout="wide")
inject_styles()

raw = load_data()
filters = sidebar_filters(raw)
data = apply_filters(raw, **filters)

st.markdown("# Home Equity Analysis")
st.markdown("<div class='dashboard-caption'>Interactive charts · loan performance and applicant profile</div>", unsafe_allow_html=True)
st.markdown("")

if data.empty:
    st.warning("No records match the selected filters. Adjust the sidebar selections to continue.")
    st.stop()

summary = kpi_summary(data)
k1, k2, k3, k4 = st.columns(4)
k1.metric("Applications", f"{summary['applications']:,}")
k2.metric("Default / delinquency rate", f"{summary['default_rate']:.1%}", help="BAD=1 divided by all filtered applications.")
k3.metric("Average requested loan", f"${summary['avg_loan']:,.0f}")
k4.metric("Average debt-to-income", f"{summary['avg_debtinc']:.1f}%" if pd.notna(summary["avg_debtinc"]) else "—")

with st.container(border=True):
    st.markdown("<div class='section-title'>Interactive charts</div>", unsafe_allow_html=True)
    st.caption(f"{len(data):,} applications in view · Selections in the sidebar update all charts and summary metrics.")
    left, right = st.columns(2, gap="large")
    with left:
        st.markdown("**Loan status**")
        st.plotly_chart(status_donut(data), use_container_width=True, key="status_donut")
    with right:
        st.markdown("**Requested loan amount distribution**")
        st.plotly_chart(loan_histogram(data), use_container_width=True, key="loan_histogram")
    left2, right2 = st.columns(2, gap="large")
    with left2:
        st.markdown("**Requested loan totals over time**")
        st.plotly_chart(monthly_trend(data), use_container_width=True, key="monthly_trend")
    with right2:
        st.markdown("**Applicant profile by loan status**")
        st.plotly_chart(profile_by_status(data), use_container_width=True, key="profile_status")

with st.expander("Data notes and field profile"):
    st.markdown("""
    **Measure and category roles.** `BAD` is the binary target (0 = current; 1 = default or seriously delinquent). `LOAN`, mortgage/property values, credit attributes, and debt-to-income are measures; reason, occupation, and geographic fields are categories. `APPDATE` is interpreted as a SAS date (days since 1 January 1960). The source dictionary marks APPDATE and the appended geography fields as rejected for model input; they are used here only for report slicing and time trends.

    **Calculated items.** Default rate = mean of `BAD`; average requested loan = mean of `LOAN`; debt-to-income and credit-line age summaries use the available non-missing values; LTV = `LOAN / VALUE × 100` is prepared in the data layer. No year-over-year growth or profit/margin calculation is defined in the guide or supported by this source dataset.

    **Interactivity.** The SAS guide documents a single report page named *Interactive charts*, four automatic visual objects, and automatic actions on all objects. This recreation preserves that page structure and provides synchronized report/page filters in the sidebar. SAS report object click-to-cross-filter behavior is represented with shared filters rather than custom chart-click callbacks.
    """)
    st.dataframe(field_profile(raw), use_container_width=True, hide_index=True,
                 column_config={"Missing %": st.column_config.NumberColumn(format="%.1f")})
    st.caption("Missing values are not imputed for visual summaries; Plotly/Pandas aggregates use observed values. The supplied dataset contains 5,960 rows.")
